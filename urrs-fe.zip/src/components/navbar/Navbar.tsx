import "./Navbar.css"

export default function Navbar () {
  return (
    <div className="navbar">
      <button>
        Mano renginiai
      </button>
      <p>
        URRS
      </p>
      <button>
        Prisijungti
      </button>
    </div>
  )
}
